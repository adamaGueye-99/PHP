<?php
//Classe : Entité formée d'Attributs et Méthodes  => Type
//Objet:   elements,instances d'une Classe        =>Variables

//Regles
   //1) Encapsulation  =>gerer la portéé des attributs et Methodes d'une Classe
            //Portéé
               //private => acces limité a la Classe
               //public => acces illimité
               //protected => 
   //Surchage de methode=>une methode qui différente maniere d'utilisation
    /*  
      function is_empty($nbre,$sms=null){

     }
      is_empty(2);
      is_empty(2,"Ce doit etre positif");

    */
     
     
   //Heritage
      //Classe Abstraites
      //Interface  
      //Polymorphisme
      //Redefinition          

//github //creer un compte
//git //installer

 
//A) Attributs  doivent etre à private
          //Instance=> spécifique à un objet de la classe
           
          //Classe=> partagé  à l'ensemble des objets de la classe
           
          

//B)Methodes   doivent etre à public

          //1)Methodes  Instances=>methodes associées à une instance ou Objet
               //a) Methodes concretes=> dont on connait la définition
                  //Exemple 
                      //constructeurs => Construire un Objet
                      //getter/setters
                      //getters => accesseurs
                      //setters => mutateurs=> modifier la valeur d'un attribut
                      //metiers=>UC
                
               //b)Methodes abstraites => dont on ne connait pas encore sa défition 
                //Exemple 
                       //metiers=>UC

          //2)Methodes de Classe=> methodes partagées à l'ensemble des instances ou Objet
               //a) Methodes concretes
                 //Exemple 
                    //getter/setters
                    //metiers=>UC
               //b) Methodes astraite
                 //Exemple 
                   //metiers=>UC




?>